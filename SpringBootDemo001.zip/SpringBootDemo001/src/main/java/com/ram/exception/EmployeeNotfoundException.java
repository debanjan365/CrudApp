package com.ram.exception;

public class EmployeeNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
